// DTO are data transfer objects used to transfer data over network
// i.e how we need data 
// helps in maintaing the shape of the data that is shared across the application

//DTOs define the shape of data of an incoming request, 
//and allows us to re-use the definition throughout the application.

import {IsNotEmpty} from 'class-validator';

export class CreateTaskDto {
    @IsNotEmpty()
    title: string;

    @IsNotEmpty()
    description: string;
}