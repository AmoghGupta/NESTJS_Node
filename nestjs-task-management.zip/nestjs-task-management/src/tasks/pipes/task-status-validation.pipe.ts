import { PipeTransform, ArgumentMetadata, BadRequestException } from "@nestjs/common";
import { TaskStatus } from "../task-status.enum";
// import { TaskStatus } from '../task.model';


// when pipes throw error we send BadRequestException error to client

// custom pipe
export class TaskStatusValidationPipe implements PipeTransform{

    readonly allowedStatues = [
        TaskStatus.OPEN,
        TaskStatus.IN_PROGRESS,
        TaskStatus.DONE
    ]
    
    // this method is from PipeTransform interface
    transform(value:any, metaData: ArgumentMetadata){
        value = value.toUpperCase();
        if(!this.isStatusValid(value)){
            throw new BadRequestException(`${value} is invalid`);
        }
        return value;
    }

    isStatusValid(value):boolean{
        return this.allowedStatues.includes(value);
    }

}