import { createParamDecorator } from "@nestjs/common";
import { User } from "./user.entity";

//create a custom decorator to extract user information from the request
export const GetUser = createParamDecorator((data, req):User=>{
    return req.user;
});