import { Injectable, UnauthorizedException } from '@nestjs/common';
import { UserRepository } from './user.repository';
import { InjectRepository } from '@nestjs/typeorm';
import { AuthCredentialsDTO } from './dto/auth-credentials.dto';
import { JwtService } from '@nestjs/jwt';
import { IJwtPayload } from './jwt-payload.interface';

@Injectable()
export class AuthService {

    
    constructor(
        @InjectRepository(UserRepository)
        private userRepository:UserRepository,
        private jwtService:JwtService
    ){

    }


    async signUp(authCredentialsDTO:AuthCredentialsDTO): Promise<void>{
        return this.userRepository.signUp(authCredentialsDTO);
    }

    async signIn(authCredentialsDTO:AuthCredentialsDTO):Promise<{accessToken:string}>{
        const username = await this.userRepository.validateUserPassword(authCredentialsDTO);
        if(!username){
            throw new UnauthorizedException('invalid user');
        }

        // once user is signed in we generate a jwt token for him
        // this jwt token is generated based on the payload which we create
        // payload is nothing but an object containing information
        // always remember payload shouldnt have any secure information
        // its just simple user infor
        const payload:IJwtPayload = {username};

        //How a token is generated?
        // JWT token is a combinatoin of three things:
        // header.payload.signature 
        // signature is a result of the header and payload processed against a secret
        
        /*********TOKEN GENERATION *************/
        const accessToken  = await this.jwtService.sign(payload);
        return {accessToken};

        
    }
}
