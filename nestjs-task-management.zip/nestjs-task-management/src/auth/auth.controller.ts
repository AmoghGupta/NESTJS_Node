import { Controller, Post, Body, ValidationPipe, UnauthorizedException, UseGuards, Req } from '@nestjs/common';
import { AuthCredentialsDTO } from './dto/auth-credentials.dto';
import { AuthService } from './auth.service';

@Controller('auth')
export class AuthController {

    constructor(private authService: AuthService){

    }

    @Post('/signup')
    signup(@Body(ValidationPipe) authCredentialsDto:AuthCredentialsDTO):Promise<void>{
        return this.authService.signUp(authCredentialsDto);
    }

    @Post('/signin')
    signin(@Body(ValidationPipe) authCredentialsDto:AuthCredentialsDTO):Promise<{accessToken:string}>{
        return this.authService.signIn(authCredentialsDto);
    }
}
