import { BaseEntity, Entity, PrimaryGeneratedColumn, Column, Unique, OneToMany } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { Task } from '../tasks/task.entity';

@Entity()
@Unique(['username'])
export class User extends BaseEntity{
    
    @PrimaryGeneratedColumn()
    id:number;

    @Column()
    username: string;

    @Column()
    password: string;

    @Column()
    salt: string;


    // one to many or many to one relationship
    // this allows us to define a relationship b/w one entity to another
    @OneToMany(type => Task, task => task.user, {eager: true})
    tasks: Task[]

    async validatePassword(password: string):Promise<boolean>{
        //get user password, convert it to the hash using the string and the salt
        // then compare the hash with the hash stored in the database
        const hash = await bcrypt.hash(password, this.salt);
        return hash==this.password;
    }
}