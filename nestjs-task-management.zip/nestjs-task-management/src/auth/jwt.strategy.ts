import {PassportStrategy} from "@nestjs/passport";
import {Strategy, ExtractJwt} from "passport-jwt";
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { IJwtPayload } from './jwt-payload.interface';
import { InjectRepository } from "@nestjs/typeorm";
import { UserRepository } from './user.repository';
import { User } from "./user.entity";


//JWT strategy is autmatically called/used whenever an api call is made
// (if authorization is enabled in that call) 
// for example (like this)==> @UseGuards(AuthGuard()) 

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy){


     /************TOKEN VALIDATION ***************/
    // How the JWT token is validated?
    // to validate the token we take the header and payload from the request token and regenerate the signature,
    // using our secret, we then compare the result signature with the signature sent in the token.


    constructor(
        @InjectRepository(UserRepository)
        private userRepository:UserRepository
    ){
        super({
            jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
            secretOrKey : 'topSecret51'
        });
    }

    // this validate method is called automatically
    // once the JWT token is authenticated
    async validate(payload: IJwtPayload): Promise<User>{
        const {username} = payload;
        const user = await this.userRepository.findOne({username});

        if(!user){
            throw new UnauthorizedException();
        }

        return user;
    }
}